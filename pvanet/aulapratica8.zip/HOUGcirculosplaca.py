'''
 Imgproc.HoughCircles(gray, circles, Imgproc.HOUGH_GRADIENT, 1.0,
                (double)gray.rows()/16, // change this value to detect circles with different distances to each other
                100.0, 30.0, 1, 30); // change the last two parameters
                // (min_radius & max_radius) to detect larger circles
with the arguments:
gray: Input image (grayscale).
circles: A vector that stores sets of 3 values: xc,yc,r for each detected circle.
HOUGH_GRADIENT: Define the detection method. Currently this is the only one available in OpenCV.
dp = 1: The inverse ratio of resolution.
min_dist = gray.rows/16: Minimum distance between detected centers.
param_1 = 200: Upper threshold for the internal Canny edge detector.
param_2 = 100*: Threshold for center detection.
min_radius = 0: Minimum radius to be detected. If unknown, put zero as default.
max_radius = 0: Maximum radius to be detected. If unknown, put zero as defa

'''


import sys
import cv2 as cv
import numpy as np
def main(argv):
    
    default_file =  "PLACAS.png"
    filename = argv[0] if len(argv) > 0 else default_file
    # Loads an image
    src = cv.imread(filename, cv.IMREAD_COLOR)
    # Check if image is loaded fine
    if src is None:
        print ('Error opening image!')
        print ('Usage: hough_circle.py [image_name -- default ' + default_file + '] \n')
        return -1

    largura_desejada =800 

    height, width, depth = src.shape
    imgScale = largura_desejada/width
    newX,newY = src.shape[1]*imgScale, src.shape[0]*imgScale
    src = cv.resize(src,(int(newX),int(newY)))
        
    
    gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)
    
    
    gray = cv.medianBlur(gray, 5)
    
    
    rows = gray.shape[0]
    circles = cv.HoughCircles(gray, cv.HOUGH_GRADIENT, 1, rows / 8,
                               param1=100, param2=30,
                               minRadius=10, maxRadius=50)
    
    
    if circles is not None:
        circles = np.uint16(np.around(circles))
        for i in circles[0, :]:
            center = (i[0], i[1])
            # circle center
            cv.circle(src, center, 1, (20, 100, 255), 2)
            # circle outline
            radius = i[2]
            cv.circle(src, center, radius, (255, 0, 0), 2)
    
    
    cv.imshow("detected circles", src)
    cv.waitKey(0)
    
    return 0
if __name__ == "__main__":
    main(sys.argv[1:])
